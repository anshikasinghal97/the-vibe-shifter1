import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { AnimatedCharacter } from './AnimatedCharacter';
import { MoodType } from '../types/game';
import { Music, Image as ImageIcon, Gamepad2, RefreshCw, Heart, Smile } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ActivityScreenProps {
  mood: MoodType;
  userName: string;
  onRestart: () => void;
}

export function ActivityScreen({ mood, userName, onRestart }: ActivityScreenProps) {
  const getMoodMessage = () => {
    switch (mood) {
      case 'stressed':
      case 'anxious':
        return {
          title: "Let's help you relax, " + userName,
          message: "I can sense you're going through a tough time. Here are some calming activities specially for you.",
          emoji: "🌸"
        };
      case 'sad':
        return {
          title: "Sending you positive vibes, " + userName,
          message: "It's okay to feel down sometimes. Let's turn that frown upside down!",
          emoji: "🌈"
        };
      case 'neutral':
        return {
          title: "Let's add some excitement, " + userName,
          message: "You're doing fine! Let's make your day even better!",
          emoji: "⭐"
        };
      case 'happy':
        return {
          title: "You're glowing, " + userName + "!",
          message: "Your positive energy is contagious! Let's keep this vibe going!",
          emoji: "✨"
        };
      case 'excited':
        return {
          title: "Wow! Amazing energy, " + userName + "!",
          message: "You're on fire! Let's channel this excitement into something awesome!",
          emoji: "🎉"
        };
    }
  };

  const getActivities = () => {
    const needsRelief = mood === 'stressed' || mood === 'anxious' || mood === 'sad';
    
    if (needsRelief) {
      return {
        music: {
          title: "Calming Music Playlist",
          description: "AI-generated soothing sounds to help you relax",
          tracks: [
            "🎵 Peaceful Piano Meditation",
            "🌊 Ocean Waves & Nature",
            "🎻 Classical Serenity",
            "🎼 Lo-Fi Study Beats"
          ]
        },
        images: [
          "peaceful sunset",
          "zen garden",
          "calm ocean"
        ],
        games: [
          {
            name: "Breathing Exercise",
            description: "Follow the circle: Breathe in for 4, hold for 4, breathe out for 4",
            icon: "🫁"
          },
          {
            name: "Gratitude Journal",
            description: "Think of 3 things you're grateful for today",
            icon: "📝"
          },
          {
            name: "Progressive Relaxation",
            description: "Tense and relax each muscle group for instant calm",
            icon: "💆"
          }
        ]
      };
    } else {
      return {
        music: {
          title: "Energizing Music Mix",
          description: "Upbeat tunes to match your awesome mood",
          tracks: [
            "🎵 Feel Good Pop Hits",
            "🎸 Upbeat Rock Anthems",
            "🎹 Dance Party Mix",
            "🎺 Happy Jazz Vibes"
          ]
        },
        images: [
          "celebration party",
          "adventure mountain",
          "colorful festival"
        ],
        games: [
          {
            name: "Quick Dance Break",
            description: "Dance to your favorite song for 2 minutes!",
            icon: "💃"
          },
          {
            name: "Creativity Burst",
            description: "Doodle or write something fun for 3 minutes",
            icon: "🎨"
          },
          {
            name: "Random Act of Kindness",
            description: "Send a nice message to someone you care about",
            icon: "💌"
          }
        ]
      };
    }
  };

  const moodInfo = getMoodMessage();
  const activities = getActivities();

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-500 p-4 py-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header Card */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-3xl mb-2">
                {moodInfo.title} {moodInfo.emoji}
              </CardTitle>
              <CardDescription className="text-lg">{moodInfo.message}</CardDescription>
            </CardHeader>
            <CardContent>
              <AnimatedCharacter mood={mood} />
            </CardContent>
          </Card>
        </motion.div>

        {/* Activities Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Music Section */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Music className="w-6 h-6 text-purple-600" />
                  <CardTitle>{activities.music.title}</CardTitle>
                </div>
                <CardDescription>{activities.music.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {activities.music.tracks.map((track, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.3 + index * 0.1 }}
                      className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-900/40 transition-colors cursor-pointer"
                    >
                      {track}
                    </motion.div>
                  ))}
                </div>
                <p className="mt-4 text-sm text-muted-foreground">
                  💡 These would be AI-generated using ElevenLabs or similar services
                </p>
              </CardContent>
            </Card>
          </motion.div>

          {/* Images Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ImageIcon className="w-6 h-6 text-pink-600" />
                  <CardTitle>Mood-Boosting Images</CardTitle>
                </div>
                <CardDescription>Beautiful AI-generated images for you</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-3">
                  {activities.images.map((query, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.4 + index * 0.1 }}
                      className="aspect-square rounded-lg overflow-hidden"
                    >
                      <ImageWithFallback
                        src={`https://source.unsplash.com/400x400/?${query.replace(' ', ',')}`}
                        alt={query}
                        className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                      />
                    </motion.div>
                  ))}
                </div>
                <p className="mt-4 text-sm text-muted-foreground">
                  💡 These can be generated using DALL-E or Stable Diffusion
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Interactive Activities */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Gamepad2 className="w-6 h-6 text-green-600" />
                <CardTitle>Quick Activities</CardTitle>
              </div>
              <CardDescription>Try these fun activities right now!</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                {activities.games.map((game, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 + index * 0.1 }}
                  >
                    <Card className="hover:shadow-lg transition-shadow cursor-pointer bg-gradient-to-br from-white to-purple-50 dark:from-gray-800 dark:to-purple-900/20">
                      <CardContent className="pt-6">
                        <div className="text-4xl mb-3 text-center">{game.icon}</div>
                        <h3 className="mb-2 text-center">{game.name}</h3>
                        <p className="text-sm text-muted-foreground text-center">
                          {game.description}
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Mood Summary */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/40 dark:to-pink-900/40">
            <CardContent className="pt-6">
              <div className="flex items-center justify-center gap-4 flex-wrap">
                <Heart className="w-8 h-8 text-red-500" />
                <p className="text-lg text-center">
                  Remember: You're doing amazing, and it's okay to take breaks. You've got this! 
                </p>
                <Smile className="w-8 h-8 text-yellow-500" />
              </div>
              <div className="flex justify-center mt-6">
                <Button
                  onClick={onRestart}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Start New Session
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
