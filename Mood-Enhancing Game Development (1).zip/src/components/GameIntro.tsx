import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { AnimatedCharacter } from './AnimatedCharacter';
import { User } from '../types/game';

interface GameIntroProps {
  user: User;
  onStart: () => void;
}

export function GameIntro({ user, onStart }: GameIntroProps) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-4">
      <Card className="max-w-2xl w-full">
        <CardHeader className="text-center">
          <CardTitle className="text-4xl mb-2">Welcome, {user.name}! 👋</CardTitle>
          <CardDescription className="text-lg">
            Meet your AI mood companion who will help you feel better
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <AnimatedCharacter mood="excited" />
          
          <div className="space-y-4 text-center">
            <p>
              I'm here to help you relax and feel amazing! Here's how it works:
            </p>
            
            <div className="grid gap-4 text-left">
              <div className="flex gap-3 items-start">
                <div className="bg-purple-100 dark:bg-purple-900 p-2 rounded-full">
                  <span className="text-2xl">1️⃣</span>
                </div>
                <div>
                  <p>
                    Answer some questions so I can understand how you're feeling
                  </p>
                </div>
              </div>
              
              <div className="flex gap-3 items-start">
                <div className="bg-purple-100 dark:bg-purple-900 p-2 rounded-full">
                  <span className="text-2xl">2️⃣</span>
                </div>
                <div>
                  <p>
                    We'll have some fun with playful questions to boost your mood
                  </p>
                </div>
              </div>
              
              <div className="flex gap-3 items-start">
                <div className="bg-purple-100 dark:bg-purple-900 p-2 rounded-full">
                  <span className="text-2xl">3️⃣</span>
                </div>
                <div>
                  <p>
                    I'll create personalized activities, music, and images just for you
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
              <p>
                ⏱️ This journey takes about 5 minutes. Take your time and be honest!
              </p>
            </div>

            <Button
              size="lg"
              onClick={onStart}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              Let's Begin! ✨
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
