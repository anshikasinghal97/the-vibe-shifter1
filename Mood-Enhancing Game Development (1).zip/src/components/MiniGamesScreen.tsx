import { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { AnimatedCharacter } from './AnimatedCharacter';
import { MoodType } from '../types/game';
import { MemoryGame } from './games/MemoryGame';
import { ColorMatchGame } from './games/ColorMatchGame';
import { BreathingGame } from './games/BreathingGame';
import { StressReliefGame } from './games/StressReliefGame';
import { PatternGame } from './games/PatternGame';
import { Gamepad2, Brain, Heart, Zap, Sparkles } from 'lucide-react';

interface MiniGamesScreenProps {
  mood: MoodType;
  onComplete: () => void;
}

type GameType = 'menu' | 'memory' | 'color' | 'breathing' | 'stress' | 'pattern';

export function MiniGamesScreen({ mood, onComplete }: MiniGamesScreenProps) {
  const [currentGame, setCurrentGame] = useState<GameType>('menu');
  const [gamesCompleted, setGamesCompleted] = useState<string[]>([]);

  const handleGameComplete = (gameName: string) => {
    if (!gamesCompleted.includes(gameName)) {
      setGamesCompleted([...gamesCompleted, gameName]);
    }
    setCurrentGame('menu');
  };

  const games = [
    {
      id: 'memory',
      name: 'Memory Match',
      description: 'Find matching pairs to boost your memory!',
      icon: Brain,
      color: 'from-purple-500 to-pink-500',
      recommended: ['stressed', 'anxious', 'neutral'],
    },
    {
      id: 'color',
      name: 'Color Match',
      description: 'Quick thinking game to sharpen your focus!',
      icon: Zap,
      color: 'from-yellow-500 to-orange-500',
      recommended: ['sad', 'neutral', 'happy'],
    },
    {
      id: 'breathing',
      name: 'Breath Exercise',
      description: 'Calm your mind with guided breathing',
      icon: Heart,
      color: 'from-blue-500 to-cyan-500',
      recommended: ['stressed', 'anxious', 'sad'],
    },
    {
      id: 'stress',
      name: 'Pop the Stress',
      description: 'Release tension by popping stress bubbles!',
      icon: Sparkles,
      color: 'from-red-500 to-pink-500',
      recommended: ['stressed', 'anxious'],
    },
    {
      id: 'pattern',
      name: 'Pattern Challenge',
      description: 'Test your memory with pattern sequences',
      icon: Gamepad2,
      color: 'from-green-500 to-emerald-500',
      recommended: ['neutral', 'happy', 'excited'],
    },
  ];

  const renderGame = () => {
    switch (currentGame) {
      case 'memory':
        return <MemoryGame onComplete={() => handleGameComplete('memory')} />;
      case 'color':
        return <ColorMatchGame onComplete={() => handleGameComplete('color')} />;
      case 'breathing':
        return <BreathingGame onComplete={() => handleGameComplete('breathing')} />;
      case 'stress':
        return <StressReliefGame onComplete={() => handleGameComplete('stress')} />;
      case 'pattern':
        return <PatternGame onComplete={() => handleGameComplete('pattern')} />;
      default:
        return null;
    }
  };

  if (currentGame !== 'menu') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-4 flex items-center justify-center">
        <Card className="max-w-2xl w-full">
          <CardHeader>
            <Button
              variant="outline"
              onClick={() => setCurrentGame('menu')}
              className="w-fit mb-4"
            >
              ← Back to Menu
            </Button>
          </CardHeader>
          <CardContent>
            {renderGame()}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-500 via-fuchsia-500 to-pink-500 p-4 py-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-3xl mb-2">
                Time for Fun Mini-Games! 🎮
              </CardTitle>
              <CardDescription className="text-lg">
                Play these mind-refreshing games to boost your mood and relax
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AnimatedCharacter mood={mood} />
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {games.map((game, index) => {
            const Icon = game.icon;
            const isRecommended = game.recommended.includes(mood);
            const isCompleted = gamesCompleted.includes(game.id);

            return (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className={`cursor-pointer hover:shadow-xl transition-all ${
                  isRecommended ? 'ring-2 ring-yellow-400' : ''
                }`}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className={`p-3 rounded-lg bg-gradient-to-br ${game.color}`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      {isCompleted && (
                        <span className="text-2xl">✅</span>
                      )}
                    </div>
                    <CardTitle className="mt-4 flex items-center gap-2">
                      {game.name}
                      {isRecommended && (
                        <span className="text-xs bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300 px-2 py-1 rounded-full">
                          Recommended
                        </span>
                      )}
                    </CardTitle>
                    <CardDescription>{game.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button
                      onClick={() => setCurrentGame(game.id as GameType)}
                      className={`w-full bg-gradient-to-r ${game.color}`}
                    >
                      {isCompleted ? 'Play Again' : 'Play Now'}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="bg-gradient-to-r from-green-100 to-blue-100 dark:from-green-900/40 dark:to-blue-900/40">
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">🎯</span>
                  <div>
                    <p className="text-lg">
                      {gamesCompleted.length === 0 && "Choose any game to start refreshing your mind!"}
                      {gamesCompleted.length > 0 && gamesCompleted.length < 3 && 
                        `Great job! You've completed ${gamesCompleted.length} game${gamesCompleted.length > 1 ? 's' : ''}!`}
                      {gamesCompleted.length >= 3 && "Amazing! You're doing fantastic! 🌟"}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Play as many as you like, or continue when you're ready
                    </p>
                  </div>
                </div>
                <Button
                  onClick={onComplete}
                  size="lg"
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  Continue to Activities →
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
