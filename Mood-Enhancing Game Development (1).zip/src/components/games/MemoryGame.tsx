import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';

const emojis = ['🌟', '🎨', '🎵', '🌈', '🎭', '🎪', '🎨', '🌸'];

export function MemoryGame({ onComplete }: { onComplete: () => void }) {
  const [cards, setCards] = useState<string[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);

  useEffect(() => {
    // Create pairs and shuffle
    const shuffled = [...emojis, ...emojis]
      .sort(() => Math.random() - 0.5);
    setCards(shuffled);
  }, []);

  const handleCardClick = (index: number) => {
    if (flipped.length === 2 || flipped.includes(index) || matched.includes(index)) {
      return;
    }

    const newFlipped = [...flipped, index];
    setFlipped(newFlipped);

    if (newFlipped.length === 2) {
      setMoves(moves + 1);
      const [first, second] = newFlipped;
      
      if (cards[first] === cards[second]) {
        setMatched([...matched, first, second]);
        setFlipped([]);
        
        if (matched.length + 2 === cards.length) {
          setTimeout(() => onComplete(), 1000);
        }
      } else {
        setTimeout(() => setFlipped([]), 1000);
      }
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-center">
        <p className="text-lg">Match all the pairs! 🎯</p>
        <p className="text-sm text-muted-foreground">Moves: {moves}</p>
      </div>
      <div className="grid grid-cols-4 gap-3 max-w-md mx-auto">
        {cards.map((emoji, index) => {
          const isFlipped = flipped.includes(index) || matched.includes(index);
          return (
            <motion.div
              key={index}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Card
                className={`cursor-pointer h-20 flex items-center justify-center ${
                  matched.includes(index) ? 'bg-green-100 dark:bg-green-900' : ''
                }`}
                onClick={() => handleCardClick(index)}
              >
                <CardContent className="p-0">
                  <motion.div
                    initial={false}
                    animate={{ rotateY: isFlipped ? 0 : 180 }}
                    transition={{ duration: 0.3 }}
                    style={{ transformStyle: 'preserve-3d' }}
                    className="text-3xl"
                  >
                    {isFlipped ? emoji : '❓'}
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
