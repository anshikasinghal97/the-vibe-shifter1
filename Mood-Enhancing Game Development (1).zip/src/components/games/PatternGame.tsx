import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Button } from '../ui/button';

const colors = ['bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500'];

export function PatternGame({ onComplete }: { onComplete: () => void }) {
  const [pattern, setPattern] = useState<number[]>([]);
  const [userPattern, setUserPattern] = useState<number[]>([]);
  const [displaying, setDisplaying] = useState(false);
  const [currentDisplayIndex, setCurrentDisplayIndex] = useState(-1);
  const [level, setLevel] = useState(1);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);

  const generateNewPattern = () => {
    const newPattern = [...pattern, Math.floor(Math.random() * 4)];
    setPattern(newPattern);
    setUserPattern([]);
    playPattern(newPattern);
  };

  const playPattern = (patternToPlay: number[]) => {
    setDisplaying(true);
    let index = 0;
    
    const interval = setInterval(() => {
      if (index < patternToPlay.length) {
        setCurrentDisplayIndex(patternToPlay[index]);
        setTimeout(() => setCurrentDisplayIndex(-1), 400);
        index++;
      } else {
        clearInterval(interval);
        setDisplaying(false);
      }
    }, 800);
  };

  const handleColorClick = (colorIndex: number) => {
    if (displaying || gameOver) return;

    const newUserPattern = [...userPattern, colorIndex];
    setUserPattern(newUserPattern);

    // Check if correct
    if (newUserPattern[newUserPattern.length - 1] !== pattern[newUserPattern.length - 1]) {
      setGameOver(true);
      setTimeout(() => onComplete(), 2000);
      return;
    }

    // Check if pattern complete
    if (newUserPattern.length === pattern.length) {
      setLevel(level + 1);
      if (level >= 5) {
        setTimeout(() => onComplete(), 1500);
      } else {
        setTimeout(() => generateNewPattern(), 1000);
      }
    }
  };

  const startGame = () => {
    setGameStarted(true);
    generateNewPattern();
  };

  if (!gameStarted) {
    return (
      <div className="text-center space-y-4">
        <h3 className="text-2xl">Pattern Memory Challenge! 🧠</h3>
        <p>Watch the pattern and repeat it by clicking the colors</p>
        <p className="text-sm text-muted-foreground">Complete 5 levels to win!</p>
        <Button onClick={startGame} size="lg">Start Challenge!</Button>
      </div>
    );
  }

  if (gameOver) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center space-y-4"
      >
        <p className="text-4xl">🎯</p>
        <h3 className="text-2xl">Great effort!</h3>
        <p>You reached level {level}!</p>
      </motion.div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <p className="text-2xl mb-2">Level {level}</p>
        <p className="text-sm text-muted-foreground">
          {displaying ? 'Watch carefully...' : 'Your turn! Repeat the pattern'}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
        {colors.map((color, index) => (
          <motion.button
            key={index}
            onClick={() => handleColorClick(index)}
            className={`h-32 rounded-lg ${color} ${
              currentDisplayIndex === index ? 'opacity-100' : 'opacity-50'
            } ${displaying ? 'cursor-not-allowed' : 'cursor-pointer hover:opacity-75'}`}
            whileHover={!displaying ? { scale: 1.05 } : {}}
            whileTap={!displaying ? { scale: 0.95 } : {}}
            animate={{
              opacity: currentDisplayIndex === index ? 1 : 0.5,
              scale: currentDisplayIndex === index ? 1.1 : 1,
            }}
            transition={{ duration: 0.2 }}
          />
        ))}
      </div>
    </div>
  );
}
