import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../ui/button';

interface Bubble {
  id: number;
  x: number;
  y: number;
  emoji: string;
}

const stressEmojis = ['😤', '😰', '😓', '😩', '😫'];
const happyEmojis = ['😊', '😄', '🎉', '⭐', '✨', '💖'];

export function StressReliefGame({ onComplete }: { onComplete: () => void }) {
  const [bubbles, setBubbles] = useState<Bubble[]>([]);
  const [popped, setPopped] = useState(0);
  const [timeLeft, setTimeLeft] = useState(20);
  const [started, setStarted] = useState(false);
  const [nextId, setNextId] = useState(0);

  useEffect(() => {
    if (!started) return;

    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setTimeout(() => onComplete(), 2000);
    }
  }, [timeLeft, started, onComplete]);

  useEffect(() => {
    if (!started || timeLeft === 0) return;

    const interval = setInterval(() => {
      const newBubble: Bubble = {
        id: nextId,
        x: Math.random() * 80 + 10,
        y: 100,
        emoji: stressEmojis[Math.floor(Math.random() * stressEmojis.length)],
      };
      setBubbles((prev) => [...prev, newBubble]);
      setNextId(nextId + 1);

      // Remove old bubbles
      setTimeout(() => {
        setBubbles((prev) => prev.filter((b) => b.id !== newBubble.id));
      }, 4000);
    }, 800);

    return () => clearInterval(interval);
  }, [started, timeLeft, nextId]);

  const popBubble = (id: number) => {
    setBubbles((prev) => prev.filter((b) => b.id !== id));
    setPopped(popped + 1);
  };

  const startGame = () => {
    setStarted(true);
    setBubbles([]);
    setPopped(0);
  };

  if (!started) {
    return (
      <div className="text-center space-y-4">
        <h3 className="text-2xl">Pop the Stress Away! 💥</h3>
        <p>Click on the stress bubbles to pop them!</p>
        <p className="text-sm text-muted-foreground">20 seconds of stress relief</p>
        <Button onClick={startGame} size="lg">Start Popping!</Button>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="flex justify-between items-center mb-4">
        <p>Popped: {popped}</p>
        <p>Time: {timeLeft}s</p>
      </div>

      <div className="relative h-96 bg-gradient-to-b from-blue-100 to-purple-100 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg overflow-hidden">
        <AnimatePresence>
          {bubbles.map((bubble) => (
            <motion.div
              key={bubble.id}
              initial={{ y: bubble.y + '%', x: bubble.x + '%', scale: 0 }}
              animate={{ y: '-20%', scale: 1 }}
              exit={{ scale: 0 }}
              transition={{ duration: 4, ease: 'linear' }}
              onClick={() => popBubble(bubble.id)}
              className="absolute cursor-pointer text-4xl hover:scale-125 transition-transform"
              whileHover={{ scale: 1.3 }}
              whileTap={{ scale: 0 }}
            >
              {bubble.emoji}
            </motion.div>
          ))}
        </AnimatePresence>

        {timeLeft === 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute inset-0 flex flex-col items-center justify-center bg-white/90 dark:bg-black/90"
          >
            <div className="text-6xl mb-4">
              {happyEmojis[Math.floor(Math.random() * happyEmojis.length)]}
            </div>
            <p className="text-2xl">You popped {popped} stress bubbles!</p>
            <p className="text-lg text-muted-foreground">Feeling lighter? 😌</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
