export type MoodType = 'stressed' | 'anxious' | 'sad' | 'neutral' | 'happy' | 'excited';

export interface Question {
  id: number;
  text: string;
  category: 'mood-detection' | 'fun' | 'stress-relief';
  options: {
    text: string;
    moodImpact: {
      stressed?: number;
      anxious?: number;
      sad?: number;
      neutral?: number;
      happy?: number;
      excited?: number;
    };
  }[];
}

export interface User {
  email: string;
  name: string;
}

export interface GameState {
  currentQuestionIndex: number;
  answers: number[];
  moodScores: {
    stressed: number;
    anxious: number;
    sad: number;
    neutral: number;
    happy: number;
    excited: number;
  };
  startTime: number;
  currentMood: MoodType;
  phase: 'detection' | 'improvement' | 'activities';
}
